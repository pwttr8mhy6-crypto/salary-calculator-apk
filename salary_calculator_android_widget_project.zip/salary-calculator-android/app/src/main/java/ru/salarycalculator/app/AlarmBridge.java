package ru.salarycalculator.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.webkit.JavascriptInterface;
import org.json.JSONArray;
import org.json.JSONObject;

public class AlarmBridge {
    private final Context context;
    public AlarmBridge(Context c) { context = c.getApplicationContext(); }
    @JavascriptInterface public void scheduleAlarms(String json) {
        try {
            android.content.SharedPreferences prefs = context.getSharedPreferences("salary_alarm_prefs", Context.MODE_PRIVATE);
            if (json.equals(prefs.getString("last_payload", ""))) return;
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            JSONArray old = new JSONArray(prefs.getString("pending_ids", "[]"));
            for (int i=0;i<old.length();i++) {
                int oldId=old.optInt(i, -1); if(oldId<0) continue;
                Intent oldIntent=new Intent(context, ShiftAlarmReceiver.class);
                PendingIntent oldPi=PendingIntent.getBroadcast(context,oldId,oldIntent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                am.cancel(oldPi); oldPi.cancel();
            }
            JSONObject root = new JSONObject(json);
            JSONArray items = root.optJSONArray("items");
            if(items == null) items = new JSONArray();
            JSONArray newIds = new JSONArray();
            for(int i=0;i<items.length();i++) {
                JSONObject item=items.getJSONObject(i);
                int id=item.optInt("id", i+1);
                Intent intent=new Intent(context, ShiftAlarmReceiver.class);
                intent.putExtra("title",item.optString("title","Скоро рабочая смена"));
                intent.putExtra("message",item.optString("message","Проверь календарь смен"));
                intent.putExtra("id",id);
                PendingIntent pi=PendingIntent.getBroadcast(context,id,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                long at=item.optLong("at",0L);
                if(at>System.currentTimeMillis()) {
                    if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
                    else am.set(AlarmManager.RTC_WAKEUP,at,pi);
                    newIds.put(id);
                } else { am.cancel(pi); pi.cancel(); }
            }
            prefs.edit().putString("pending_ids",newIds.toString()).putString("last_payload",json).apply();
        } catch(Exception ignored) { }
    }
    @JavascriptInterface public void testNotification() {
        Intent intent = new Intent(context, ShiftAlarmReceiver.class);
        intent.putExtra("title","Тестовое уведомление");
        intent.putExtra("message","Уведомления калькулятора работают.");
        intent.putExtra("id",999999);
        context.sendBroadcast(intent);
    }
}
