package ru.salarycalculator.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new WidgetBridge(), "AndroidWidget");
        webView.addJavascriptInterface(new AlarmBridge(this), "AndroidAlarm");
        webView.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
    }
    private class WidgetBridge {
        @JavascriptInterface public void updateCalendar(String json) {
            getSharedPreferences(CalendarWidgetProvider.PREFS, MODE_PRIVATE).edit().putString(CalendarWidgetProvider.KEY_DATA, json).apply();
            runOnUiThread(() -> {
                AppWidgetManager manager = AppWidgetManager.getInstance(MainActivity.this);
                ComponentName component = new ComponentName(MainActivity.this, CalendarWidgetProvider.class);
                int[] ids = manager.getAppWidgetIds(component);
                if (ids != null && ids.length > 0) CalendarWidgetProvider.updateAll(MainActivity.this, manager, ids);
            });
        }
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
