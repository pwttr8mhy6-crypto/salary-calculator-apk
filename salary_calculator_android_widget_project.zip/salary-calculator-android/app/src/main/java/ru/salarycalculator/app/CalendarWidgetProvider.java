package ru.salarycalculator.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.widget.RemoteViews;
import org.json.JSONObject;
import org.json.JSONArray;
import java.util.Calendar;
import java.util.Locale;

public class CalendarWidgetProvider extends AppWidgetProvider {
    public static final String PREFS = "salary_widget_prefs";
    public static final String KEY_DATA = "calendar_json";
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) { updateAll(context, manager, ids); }
    public static void updateAll(Context context, AppWidgetManager manager, int[] ids) {
        String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_DATA, null);
        for (int id : ids) {
            RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.widget_calendar);
            Intent launch = new Intent(context, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(context, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            v.setOnClickPendingIntent(R.id.widgetRoot, pi);
            try {
                JSONObject root = raw == null ? new JSONObject() : new JSONObject(raw);
                JSONObject state = root.optJSONObject("state"); if (state == null) state = new JSONObject();
                Calendar now = Calendar.getInstance();
                int year = root.optInt("viewYear", now.get(Calendar.YEAR));
                int month = root.optInt("viewMonth", now.get(Calendar.MONTH));
                String[] months = {"Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь"};
                int wd = state.optInt("workDays",3), od = state.optInt("offDays",2);
                v.setTextViewText(R.id.widgetTitle, months[Math.max(0,Math.min(11,month))] + " " + year);
                v.setTextViewText(R.id.widgetSubtitle, "График " + wd + "/" + od + " · смены и выходные");
                String cycleStart = state.optString("cycleStart", String.format(Locale.US,"%04d-%02d-%02d",year,month+1,1));
                String[] cs = cycleStart.split("-");
                Calendar start = Calendar.getInstance(); start.clear(); start.set(Integer.parseInt(cs[0]),Integer.parseInt(cs[1])-1,Integer.parseInt(cs[2]));
                JSONObject overrides = state.optJSONObject("overrides"); if (overrides == null) overrides = new JSONObject();
                JSONObject vacation = state.optJSONObject("vacation");
                String vacStart = vacation == null ? "" : vacation.optString("start","");
                String vacEnd = vacation == null ? "" : vacation.optString("end","");
                Calendar first = Calendar.getInstance(); first.clear(); first.set(year,month,1);
                int offset = (first.get(Calendar.DAY_OF_WEEK)+5)%7;
                int days = first.getActualMaximum(Calendar.DAY_OF_MONTH);
                for(int i=1;i<=42;i++) {
                    int viewId = context.getResources().getIdentifier("day_"+i,"id",context.getPackageName());
                    int day = i-offset;
                    if(day<1 || day>days) { v.setTextViewText(viewId," "); v.setInt(viewId,"setBackgroundColor",Color.WHITE); continue; }
                    String date = String.format(Locale.US,"%04d-%02d-%02d",year,month+1,day);
                    JSONObject override = overrides.optJSONObject(date);
                    String type;
                    if(override != null && override.has("type")) type=override.optString("type","off");
                    else {
                        Calendar d = Calendar.getInstance(); d.clear(); d.set(year,month,day);
                        long diff = (d.getTimeInMillis()-start.getTimeInMillis())/86400000L;
                        int cycle = Math.max(1,wd)+Math.max(1,od); int phase=(int)(((diff%cycle)+cycle)%cycle);
                        type = phase < Math.max(1,wd) ? "work" : "off";
                    }
                    boolean vac = !vacStart.isEmpty() && !vacEnd.isEmpty() && date.compareTo(vacStart)>=0 && date.compareTo(vacEnd)<=0;
                    int bg = Color.WHITE, fg = Color.rgb(23,52,81);
                    if(vac) { bg=Color.rgb(220,236,255); fg=Color.rgb(32,91,155); }
                    else if("work".equals(type)) { bg=Color.rgb(225,246,234); fg=Color.rgb(22,112,65); }
                    else if("extra".equals(type)) { bg=Color.rgb(255,239,216); fg=Color.rgb(154,86,14); }
                    else { bg=Color.rgb(242,245,249); fg=Color.rgb(100,116,139); }
                    v.setTextViewText(viewId, Integer.toString(day)); v.setTextColor(viewId,fg); v.setInt(viewId,"setBackgroundColor",bg);
                    if(date.equals(root.optString("today",""))) { v.setTextColor(viewId,Color.rgb(219,91,32)); }
                }
                v.setTextViewText(R.id.widgetFooter,"Рабочий — зелёный · выходной — серый · отпуск — синий");
            } catch(Exception e) {
                v.setTextViewText(R.id.widgetTitle,"Календарь смен");
                v.setTextViewText(R.id.widgetSubtitle,"Открой приложение, чтобы загрузить график");
            }
            manager.updateAppWidget(id,v);
        }
    }
}
